import React from 'react'

function Greet() {

    return <h1>Hello Dr K Test Functional Component</h1>
}

//Greet=() => <h1>Hello Kiru</h1>


export default Greet